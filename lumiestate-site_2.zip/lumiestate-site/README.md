# LUMI Estate — Landing Page

Landing page một trang cho **LUMI Estate** — hệ sinh thái bất động sản: Cho thuê · Xây dựng · Vận hành.

## Cấu trúc

```
index.html        # Toàn bộ trang (HTML + CSS, logo nhúng sẵn, SEO đầy đủ)
netlify.toml      # Cấu hình Netlify (cache + security headers)
robots.txt        # Cho phép bot tìm kiếm, trỏ tới sitemap
sitemap.xml       # Sơ đồ trang cho Google
assets/
  logo-gold.png   # Logo vàng (nền trong suốt)
  logo-white.png  # Logo trắng (nền trong suốt)
  favicon.png     # Favicon 64px
  icon-192.png    # Icon 192px (apple-touch-icon)
  icon-512.png    # Icon 512px (og:image)
```

## Deploy lên Netlify

**Cách 1 — Kéo thả (nhanh nhất):** vào https://app.netlify.com/drop và kéo cả thư mục này vào.

**Cách 2 — Qua GitHub:**
1. Tạo repo mới trên GitHub, push toàn bộ thư mục này lên.
2. Vào Netlify → **Add new site → Import an existing project** → chọn repo.
3. Build command để trống, Publish directory: `.` → **Deploy**.

Sau khi deploy, có thể gắn tên miền riêng (vd `lumiestate.vn`) trong **Domain settings**.

## SEO

Đã có sẵn: title/description, canonical, Open Graph + Twitter card, JSON-LD (schema.org RealEstateAgent), robots.txt, sitemap.xml. Tên miền đang khai báo là `https://lumiestate.vn` — nếu deploy ở domain khác, tìm-thay chuỗi này trong `index.html`, `robots.txt`, `sitemap.xml`.

Sau khi deploy, nên khai báo sitemap tại Google Search Console: https://search.google.com/search-console

## Liên hệ

contact@lumiestate.vn
